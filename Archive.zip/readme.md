The pandas (Python Data Analysis Library) library is required.
Run 'pip install pandas' before running load_data.py

psycopg2 is also required.
